import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, doc, getDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const root = document.querySelector("#movie-detail");
const id = new URLSearchParams(location.search).get("id");

const esc = (s) => String(s || "").replace(/[&<>"']/g, (c) => ({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}[c]));

try {
  if (!id) throw new Error("Missing movie ID");

  const app = initializeApp(firebaseConfig);
  const db = getFirestore(app);
  const snap = await getDoc(doc(db, "movies", id));

  if (!snap.exists()) throw new Error("Movie not found");

  const m = snap.data();

  root.innerHTML = `
    <div class="detail-card">
      ${m.image ? `<img class="poster" src="${esc(m.image)}" alt="">` : ""}
      <div>
        <span class="tag">${esc(m.category || "Movie")}</span>
        <h1>${esc(m.title)}</h1>
        <p>${esc(m.description)}</p>

        ${m.video ? `
          <button id="watch-movie" class="watch-movie-button" type="button">
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <circle cx="12" cy="12" r="9.2"></circle>
              <path d="m10 8 6 4-6 4z"></path>
            </svg>
            <span>WATCH MOVIE</span>
          </button>
          <p id="watch-msg" class="notice" aria-live="polite"></p>
        ` : ""}

        <div class="download-box">
          <h2>Download</h2>
          <p class="muted">Sponsored links are optional and clearly identified. After each visit, return here to continue.</p>
          <button id="download" type="button">Continue to download</button>
          <p id="download-msg" class="notice" aria-live="polite"></p>
        </div>
      </div>
    </div>
  `;

  // Watch Movie: open its two separate sponsored links in order, then the video.
  let watchStep = 0;
  const watchButton = document.querySelector("#watch-movie");
  if (watchButton) {
    watchButton.addEventListener("click", () => {
      const watchAds = [m.watchAd1, m.watchAd2].filter(Boolean);
      const message = document.querySelector("#watch-msg");

      if (watchStep < watchAds.length) {
        const url = watchAds[watchStep];
        watchStep += 1;
        message.textContent =
          `Sponsored link ${watchStep} of ${watchAds.length} opened. Return here and tap WATCH MOVIE again.`;
        window.open(url, "_blank", "noopener,noreferrer");
      } else {
        message.textContent = "Opening the movie.";
        window.open(m.video, "_blank", "noopener,noreferrer");
      }
    });
  }

  // Keep the existing Download ad sequence separate and unchanged.
  let downloadStep = 0;
  document.querySelector("#download").addEventListener("click", () => {
    const ads = [m.ad1, m.ad2].filter(Boolean);
    const message = document.querySelector("#download-msg");

    if (downloadStep < ads.length) {
      const url = ads[downloadStep];
      downloadStep += 1;
      message.textContent =
        `Opening sponsored link ${downloadStep} of ${ads.length}. Return here to continue.`;
      window.open(url, "_blank", "noopener,noreferrer");
    } else if (m.download) {
      message.textContent = "Opening the download link.";
      window.open(m.download, "_blank", "noopener,noreferrer");
    } else {
      message.textContent = "No download link has been added yet.";
    }
  });

} catch (error) {
  root.innerHTML = `<p class="muted">${esc(error.message)}. Check Firebase setup or return to the home page.</p>`;
}
